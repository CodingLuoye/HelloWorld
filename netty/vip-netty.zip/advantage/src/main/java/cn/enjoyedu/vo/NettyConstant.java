package cn.enjoyedu.vo;

/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程和VIP课程咨询 依娜老师  QQ：2133576719
 * 类说明：常量说明
 */
public final class NettyConstant {
    public static final String REMOTE_IP = "127.0.0.1";
    public static final int REMOTE_PORT = 8989;
}
