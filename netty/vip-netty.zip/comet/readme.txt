本工程展示了服务器推送技术，包括有：
1、Ajax短轮询，normal包下
2、基于 AJAX 的长轮询-Spring带来的DeferedResult，servlet3包下
3、服务器推模型Server-sent-events(SSE)，sse包下
4、Spring带来的SSE的实现emitter，emitter包下
