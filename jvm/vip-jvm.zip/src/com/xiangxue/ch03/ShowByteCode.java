package com.xiangxue.ch03;

public class ShowByteCode {
	
	private String xx;
	
	private final static int TEST = 1;
	
	public int calc() {
		int a=100;
		int b=200;
		int c=300;
		return (a+b)*c;//90000
	}
	
	//new 
	//if(){}else{}

}
