package com.xiangxue.ch03.classinit;

public class SubClazz extends SuperClazz {
	
	static {
		System.out.println("Subclass init!");
	}

}
