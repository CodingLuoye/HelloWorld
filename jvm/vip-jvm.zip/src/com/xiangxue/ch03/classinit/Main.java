package com.xiangxue.ch03.classinit;

public class Main {
	
	public static void main(String[] args) {
		//System.out.println(SubClazz.value);
		//SuperClazz[] sca = new SuperClazz[10];
		System.out.println(SubClazz.HELLOWORLD);
		//System.out.println(SubClazz.WHAT);
		
	}

}
