package com.xiangxue.ch04;

import java.util.Arrays;

public class Tools {
	
	//private Tools() {}
	
	public static void main(String[] args) {
		Tools tools = new Tools();
		//Arrays.asList(a);
	}

}
